import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Color;
import javax.swing.JLabel;
import java.awt.Font;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JTextField;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.table.DefaultTableModel;

import net.proteanit.sql.DbUtils;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class buy {

    JFrame  bframe;
	private JTextField n;
	private JTextField p;
	private JTextField edi;
	private JTable table;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					buy window = new buy();
					window.bframe.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				} 
			}
		});
	}

	/**
	 * Create the application.
	 */
	public buy() {
		initialize();
		connect();
		table_load();
	}
	public void table_load()
    {
    		try 
	    	{
		    pst = con.prepareStatement("select * from cart");
		    rs = pst.executeQuery();
		    table.setModel(DbUtils.resultSetToTableModel(rs));
		}
    	catch (SQLException e) 
    	 {
    		e.printStackTrace();
	  } 
    }
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	private JButton btnNewButton;
	private JButton btnBuy;
	private JButton btnNewButton_1;
	private JTextField tp;
	private JTextField pp;
	private JTextField b;
	private JTextField textField_2;
	private JLabel lblTransaction;
	private JTextField trans;
	

	 public void connect()
	    {
	        try {
	            Class.forName("com.mysql.cj.jdbc.Driver");
	            con = DriverManager.getConnection("jdbc:mysql://localhost/ebook", "root","");
	        }
	        catch (ClassNotFoundException ex) 
	        {
	          ex.printStackTrace();
	        }
	        catch (SQLException ex) 
	        {
	        	   ex.printStackTrace();
	        }

	    }

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		bframe = new JFrame();
		bframe.getContentPane().setBackground(Color.RED);
		bframe.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("Book");
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblNewLabel.setBounds(101, 91, 64, 23);
		bframe.getContentPane().add(lblNewLabel);
		
		JLabel lblEdition = new JLabel("Edition");
		lblEdition.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblEdition.setBounds(101, 125, 64, 23);
		bframe.getContentPane().add(lblEdition);
		
		JLabel lblPrice = new JLabel("Price");
		lblPrice.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblPrice.setBounds(101, 159, 64, 23);
		bframe.getContentPane().add(lblPrice);
		
		n = new JTextField();
		n.addKeyListener(new KeyAdapter() {
			public void keyReleased(KeyEvent e) {
				String ed,pri;
				 try {
			            String name = n.getText();
			                pst = con.prepareStatement("select name,edition,price from book where name = ?");
			                pst.setString(1, name);
			                ResultSet rs = pst.executeQuery();
			            if(rs.next()==true)
			            {
			                ed = rs.getString(2);
			                pri = rs.getString(3);
			                edi.setText(ed);
			                p.setText(pri); 
			            }  
			            else
			            {
			            	edi.setText("");
			                p.setText("");    
			            }
			        } 
				
				 catch (SQLException ex) {
			           
			        }
			
			}
		});
		
		n.setColumns(10);
		n.setBounds(184, 94, 121, 20);
		bframe.getContentPane().add(n);
		
		p = new JTextField();
		p.setColumns(10);
		p.setBounds(184, 162, 121, 20);
		bframe.getContentPane().add(p);
		
		edi = new JTextField();
		edi.setColumns(10);
		edi.setBounds(184, 128, 121, 20);
		bframe.getContentPane().add(edi);
		
		JScrollPane scrollPane = new JScrollPane();
		scrollPane.setBounds(71, 249, 460, 222);
		bframe.getContentPane().add(scrollPane);
		
		table = new JTable();
		table.setModel(new DefaultTableModel(
			new Object[][] {
			},
			new String[] {
				" Book Name", "    Edition", "      Price"
			}
		));
		scrollPane.setViewportView(table);
		
		btnNewButton = new JButton("ADD");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				String name=n.getText(),edition=edi.getText(),price=p.getText(),tprice;
				 try {
	            		pst = con.prepareStatement("insert into cart(name,edition,price)values(?,?,?)");
	            		pst.setString(1, name);
	            		pst.setString(2, edition);
	            		pst.setString(3, price);
	            		pst.executeUpdate();
	            		table_load();
	            		n.setText("");
	            		edi.setText("");
	            		p.setText("");
	            		n.requestFocus();
	            		pst = con.prepareStatement("select sum(price) from cart");
	            		ResultSet rs = pst.executeQuery();
	            		if(rs.next()==true)
			            {
			                tprice = rs.getString(1);
			                tp.setText(tprice); 
	            	    }
	            		else
			            {
	            			tp.setText(""); 
			            }
			        } 
	            	catch (SQLException e1) 
	                    {
	            						
	            	e1.printStackTrace();
	            	}
				}
		});
		btnNewButton.setBackground(Color.ORANGE);
		btnNewButton.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton.setBounds(111, 202, 89, 23);
		bframe.getContentPane().add(btnNewButton);
		
		btnBuy = new JButton("BUY");
		btnBuy.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				try 
				{
					String total=tp.getText(),ppaid=pp.getText();
					int i=Integer.parseInt(total);
					int j=Integer.parseInt(ppaid);
					int k;
        		if(j>=i)
        		{
        			k=j-i;
        			String bal=String.valueOf(k);
        			b.setText(bal);
        			pst = con.prepareStatement("truncate table cart");
            		pst.executeUpdate();
            		table_load();
            		trans.setText("Successful");
        		}
        		else
        		{
        			b.setText("");
        			trans.setText("Not Successful");
        		}
				}
				catch (Exception e2) 
                {
        			if(e2 instanceof NumberFormatException)
        			{
        				pp.setText("Enter an amount");
        			}
                }
			}	
		});
		btnBuy.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnBuy.setBackground(Color.ORANGE);
		btnBuy.setBounds(216, 202, 89, 23);
		bframe.getContentPane().add(btnBuy);
		
		btnNewButton_1 = new JButton("HOME");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				bframe.dispose();
				mainpage m=new mainpage();
				m.frame.setVisible(true);
			}
		});
		btnNewButton_1.setBackground(Color.ORANGE);
		btnNewButton_1.setFont(new Font("Tahoma", Font.BOLD, 15));
		btnNewButton_1.setBounds(10, 11, 89, 23);
		bframe.getContentPane().add(btnNewButton_1);
		
		JLabel lblTotalPrice = new JLabel("Total Price");
		lblTotalPrice.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTotalPrice.setBounds(536, 91, 106, 23);
		bframe.getContentPane().add(lblTotalPrice);
		
		tp = new JTextField();
		tp.setBounds(639, 91, 96, 20);
		bframe.getContentPane().add(tp);
		tp.setColumns(10);
		
		JLabel lblPricePaid = new JLabel("Price Paid");
		lblPricePaid.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblPricePaid.setBounds(536, 125, 106, 23);
		bframe.getContentPane().add(lblPricePaid);
		
		JLabel lblBalance = new JLabel("Balance\r\n");
		lblBalance.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblBalance.setBounds(536, 159, 89, 23);
		bframe.getContentPane().add(lblBalance);
		
		pp = new JTextField();
		pp.setColumns(10);
		pp.setBounds(639, 128, 96, 20);
		bframe.getContentPane().add(pp);
		
		b = new JTextField();
		b.setColumns(10);
		b.setBounds(639, 162, 96, 20);
		bframe.getContentPane().add(b);
		
		textField_2 = new JTextField();
		textField_2.setColumns(10);
		textField_2.setBounds(638, 205, 134, 20);
		bframe.getContentPane().add(textField_2);
		
		JLabel lblPaidBy = new JLabel("Paid By");
		lblPaidBy.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblPaidBy.setBounds(536, 202, 106, 23);
		bframe.getContentPane().add(lblPaidBy);
		
		lblTransaction = new JLabel("Transaction");
		lblTransaction.setFont(new Font("Tahoma", Font.BOLD, 16));
		lblTransaction.setBounds(541, 256, 106, 23);
		bframe.getContentPane().add(lblTransaction);
		
		trans = new JTextField();
		trans.setColumns(10);
		trans.setBounds(648, 253, 134, 20);
		bframe.getContentPane().add(trans);
		bframe.setBackground(Color.RED);
		bframe.setBounds(100, 100, 829, 519);
		bframe.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
